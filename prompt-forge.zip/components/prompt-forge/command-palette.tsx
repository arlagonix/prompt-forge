"use client";

import {
  Command,
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import type { ParsedFile } from "@/lib/prompt-forge/types";
import { FileText } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  fileMap: Map<string, ParsedFile>;
  onFileSelect: (fileId: string) => void;
}

export function CommandPalette({
  isOpen,
  onClose,
  fileMap,
  onFileSelect,
}: CommandPaletteProps) {
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (isOpen) {
      setSearch("");
    }
  }, [isOpen]);

  const files = useMemo(() => {
    return Array.from(fileMap.values()).sort((a, b) =>
      a.name.localeCompare(b.name),
    );
  }, [fileMap]);

  const filteredFiles = useMemo(() => {
    if (!search.trim()) return files.slice(0, 20);

    const query = search.toLowerCase();
    return files
      .filter((file) => file.name.toLowerCase().includes(query))
      .slice(0, 20);
  }, [files, search]);

  return (
    <CommandDialog
      open={isOpen}
      onOpenChange={(open) => !open && onClose()}
      className="top-20 translate-y-0 sm:top-24"
    >
      <Command className="rounded-lg border border-border shadow-lg">
        <CommandInput
          placeholder="Search templates..."
          value={search}
          onValueChange={setSearch}
        />
        <CommandList className="max-h-[420px] min-h-[220px] overflow-y-auto">
          <CommandEmpty>
            {files.length === 0 ? "No prompts found." : "No templates found."}
          </CommandEmpty>
          <CommandGroup heading="Templates">
            {filteredFiles.map((file) => (
              <CommandItem
                key={file.id}
                value={file.name}
                onSelect={() => onFileSelect(file.id)}
                className="flex items-center gap-2"
              >
                <FileText className="h-4 w-4 text-muted-foreground" />
                <div className="flex-1 min-w-0">
                  <p className="truncate">{file.name}</p>
                  <p className="text-xs text-muted-foreground truncate">
                    {file.path}
                  </p>
                </div>
              </CommandItem>
            ))}
          </CommandGroup>
        </CommandList>
      </Command>
    </CommandDialog>
  );
}
