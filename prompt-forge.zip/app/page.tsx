"use client";

import { CodeEditor } from "@/components/prompt-forge/code-editor";
import { CommandPalette } from "@/components/prompt-forge/command-palette";
import { DocsModal } from "@/components/prompt-forge/docs-modal";
import { MainContent } from "@/components/prompt-forge/main-content";
import { MoveFolderDialog } from "@/components/prompt-forge/move-folder-dialog";
import { MovePromptDialog } from "@/components/prompt-forge/move-prompt-dialog";
import { Sidebar } from "@/components/prompt-forge/sidebar";
import { TemplateModal } from "@/components/prompt-forge/template-modal";
import { Toaster } from "@/components/ui/sonner";
import { extractParameters } from "@/lib/prompt-forge/parser";
import {
  buildFolderTree,
  createFolder,
  createPrompt,
  deleteFolder,
  deletePrompt,
  ensureSeedData,
  getAllFolders,
  getAllPrompts,
  moveFolder,
  movePrompt,
  renameFolder,
  renamePrompt,
  updatePromptContent,
} from "@/lib/prompt-forge/storage";
import type {
  EditorState,
  FolderNode,
  Parameter,
  ParsedFile,
} from "@/lib/prompt-forge/types";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";

const DEFAULT_TEMPLATE = `---
title: New Template
description: A new prompt template
---

# Your Template

Write your prompt template here. Use {{parameter_name}} syntax for parameters.

Example: Hello, {{name}}! How can I help you today?
`;

const LAST_FILE_KEY = "prompt-forge-last-file";
const ROOT_FOLDER_ID = "root";

function flattenFolders(
  root: FolderNode,
): { id: string; name: string; path: string }[] {
  const result: { id: string; name: string; path: string }[] = [];

  function walk(folder: FolderNode) {
    result.push({
      id: folder.id,
      name: folder.name,
      path: folder.path,
    });

    for (const child of folder.children) {
      if (child.type === "directory") {
        walk(child);
      }
    }
  }

  walk(root);
  return result;
}

export default function PromptForge() {
  const [folderTree, setFolderTree] = useState<FolderNode | null>(null);
  const [fileMap, setFileMap] = useState<Map<string, ParsedFile>>(new Map());
  const [currentFile, setCurrentFile] = useState<ParsedFile | null>(null);
  const [currentParams, setCurrentParams] = useState<Parameter[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isPaletteOpen, setIsPaletteOpen] = useState(false);
  const [isDocsOpen, setIsDocsOpen] = useState(false);
  const [isTemplateOpen, setIsTemplateOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [editorState, setEditorState] = useState<EditorState>({
    isOpen: false,
    isNew: false,
    fileId: null,
    content: "",
    fileName: "",
    folderId: null,
  });
  const [movePromptState, setMovePromptState] = useState<{
    isOpen: boolean;
    promptId: string | null;
    promptName: string;
    currentFolderId: string | null;
    selectedFolderId: string;
  }>({
    isOpen: false,
    promptId: null,
    promptName: "",
    currentFolderId: null,
    selectedFolderId: "",
  });
  const [moveFolderState, setMoveFolderState] = useState<{
    isOpen: boolean;
    folderId: string | null;
    folderName: string;
    currentParentId: string | null;
    currentParentPath: string;
    selectedFolderId: string;
  }>({
    isOpen: false,
    folderId: null,
    folderName: "",
    currentParentId: null,
    currentParentPath: "/Workspace",
    selectedFolderId: "",
  });

  useEffect(() => {
    if (window.innerWidth < 768) {
      setIsSidebarOpen(false);
    }
  }, []);

  const showNotification = useCallback(
    (message: string, type: "success" | "error" = "success") => {
      if (type === "error") {
        toast.error(message);
      } else {
        toast.success(message);
      }
    },
    [],
  );

  const saveLastFile = useCallback((file: ParsedFile) => {
    try {
      localStorage.setItem(
        LAST_FILE_KEY,
        JSON.stringify({
          id: file.id,
          name: file.name,
          path: file.path,
          ts: Date.now(),
        }),
      );
    } catch {}
  }, []);

  const loadLastFile = useCallback((): {
    id?: string;
    name?: string;
    path?: string;
  } | null => {
    try {
      const raw = localStorage.getItem(LAST_FILE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }, []);

  const clearLastFile = useCallback(() => {
    try {
      localStorage.removeItem(LAST_FILE_KEY);
    } catch {}
  }, []);

  const applyCurrentFile = useCallback(
    (file: ParsedFile | null) => {
      setCurrentFile(file);
      setCurrentParams(file ? extractParameters(file.bodyContent) : []);
      if (file) {
        saveLastFile(file);
      }
    },
    [saveLastFile],
  );

  const loadWorkspace = useCallback(
    async ({
      preserveFileId,
      restoreLastFile = false,
    }: {
      preserveFileId?: string | null;
      restoreLastFile?: boolean;
    } = {}) => {
      setIsLoading(true);

      try {
        await ensureSeedData();

        const [folders, prompts] = await Promise.all([
          getAllFolders(),
          getAllPrompts(),
        ]);

        const { folderTree: nextFolderTree, fileMap: nextFileMap } =
          buildFolderTree(folders, prompts);

        setFolderTree(nextFolderTree);
        setFileMap(nextFileMap);

        let nextCurrentFile: ParsedFile | null = null;

        if (preserveFileId && nextFileMap.has(preserveFileId)) {
          nextCurrentFile = nextFileMap.get(preserveFileId) ?? null;
        } else if (restoreLastFile) {
          const lastFile = loadLastFile();
          if (lastFile?.id && nextFileMap.has(lastFile.id)) {
            nextCurrentFile = nextFileMap.get(lastFile.id) ?? null;
          } else if (lastFile?.path) {
            for (const file of nextFileMap.values()) {
              if (file.path === lastFile.path) {
                nextCurrentFile = file;
                break;
              }
            }
          }
        }

        if (
          !nextCurrentFile &&
          currentFile?.id &&
          nextFileMap.has(currentFile.id)
        ) {
          nextCurrentFile = nextFileMap.get(currentFile.id) ?? null;
        }

        if (nextCurrentFile) {
          applyCurrentFile(nextCurrentFile);
        } else {
          setCurrentFile(null);
          setCurrentParams([]);
        }
      } finally {
        setIsLoading(false);
      }
    },
    [applyCurrentFile, currentFile?.id, loadLastFile],
  );

  const selectFolder = useCallback(() => {
    showNotification(
      "Folder selection is no longer used. Prompts are now stored inside the app.",
      "error",
    );
  }, [showNotification]);

  const loadFile = useCallback(
    async (fileId: string) => {
      const file = fileMap.get(fileId);
      if (!file) {
        showNotification("Prompt not found", "error");
        return;
      }

      applyCurrentFile(file);
    },
    [fileMap, applyCurrentFile, showNotification],
  );

  const refreshFolder = useCallback(async () => {
    await loadWorkspace({ preserveFileId: currentFile?.id ?? null });
    showNotification("Workspace refreshed");
  }, [loadWorkspace, currentFile?.id, showNotification]);

  const openEditor = useCallback(
    async (fileId: string) => {
      const file = fileMap.get(fileId);
      if (!file) {
        showNotification("Failed to open prompt for editing", "error");
        return;
      }

      setEditorState({
        isOpen: true,
        isNew: false,
        fileId,
        content: file.content,
        fileName: file.name,
        folderId: file.folderId,
      });
    },
    [fileMap, showNotification],
  );

  const createNewFile = useCallback((folderId?: string) => {
    setEditorState({
      isOpen: true,
      isNew: true,
      fileId: null,
      content: DEFAULT_TEMPLATE,
      fileName: "",
      folderId: folderId ?? ROOT_FOLDER_ID,
    });
  }, []);

  const createNewFolder = useCallback(
    async (name: string, parentId?: string | null) => {
      const trimmed = name.trim();
      if (!trimmed) {
        showNotification("Folder name cannot be empty", "error");
        return;
      }

      try {
        await createFolder(trimmed, parentId ?? ROOT_FOLDER_ID);
        showNotification(`Created folder: ${trimmed}`);
        await loadWorkspace({ preserveFileId: currentFile?.id ?? null });
      } catch (err) {
        showNotification(
          `Failed to create folder: ${(err as Error).message}`,
          "error",
        );
      }
    },
    [currentFile?.id, loadWorkspace, showNotification],
  );

  const renameExistingFolder = useCallback(
    async (folderId: string, name: string) => {
      const trimmed = name.trim();
      if (!trimmed) {
        showNotification("Folder name cannot be empty", "error");
        return;
      }

      try {
        const updated = await renameFolder(folderId, trimmed);
        showNotification(`Renamed folder: ${updated.name}`);
        await loadWorkspace({ preserveFileId: currentFile?.id ?? null });
      } catch (err) {
        showNotification(
          `Failed to rename folder: ${(err as Error).message}`,
          "error",
        );
      }
    },
    [currentFile?.id, loadWorkspace, showNotification],
  );

  const deleteExistingFolder = useCallback(
    async (folderId: string) => {
      try {
        await deleteFolder(folderId);
        showNotification("Folder deleted");
        await loadWorkspace({ preserveFileId: currentFile?.id ?? null });
      } catch (err) {
        showNotification(
          `Failed to delete folder: ${(err as Error).message}`,
          "error",
        );
      }
    },
    [currentFile?.id, loadWorkspace, showNotification],
  );

  const saveFile = useCallback(
    async (content: string, newFileName?: string) => {
      try {
        const finalFileName = newFileName?.trim();

        if (!finalFileName) {
          throw new Error("Missing prompt name");
        }

        if (editorState.isNew) {
          const created = await createPrompt(
            finalFileName,
            editorState.folderId ?? ROOT_FOLDER_ID,
            content,
          );

          showNotification(`Created: ${created.name}`);
          setEditorState((prev) => ({ ...prev, isOpen: false }));

          await loadWorkspace({ preserveFileId: created.id });
        } else {
          if (!editorState.fileId) {
            throw new Error("Prompt not found");
          }

          const file = fileMap.get(editorState.fileId);
          if (!file) {
            throw new Error("Prompt not found");
          }

          let resultingName = file.name;

          if (finalFileName !== file.name) {
            const renamed = await renamePrompt(
              editorState.fileId,
              finalFileName,
            );
            resultingName = renamed.name;
          }

          const updated = await updatePromptContent(
            editorState.fileId,
            content,
          );

          showNotification(`Saved: ${resultingName}`);
          setEditorState((prev) => ({
            ...prev,
            content,
            fileName: resultingName,
            isOpen: false,
          }));

          await loadWorkspace({ preserveFileId: updated.id });
        }
      } catch (err) {
        showNotification(
          `Failed to save prompt: ${(err as Error).message}`,
          "error",
        );
        throw err;
      }
    },
    [editorState, fileMap, loadWorkspace, showNotification],
  );

  const deleteFile = useCallback(
    async (fileId: string) => {
      const file = fileMap.get(fileId);
      if (!file) {
        showNotification("Cannot delete prompt", "error");
        return;
      }

      try {
        await deletePrompt(fileId);
        showNotification(`Deleted: ${file.name}`);

        if (currentFile?.id === fileId) {
          setCurrentFile(null);
          setCurrentParams([]);
          clearLastFile();
        }

        if (editorState.fileId === fileId) {
          setEditorState((prev) => ({ ...prev, isOpen: false }));
        }

        await loadWorkspace();
      } catch (err) {
        showNotification(
          `Failed to delete prompt: ${(err as Error).message}`,
          "error",
        );
      }
    },
    [
      fileMap,
      currentFile,
      editorState.fileId,
      loadWorkspace,
      showNotification,
      clearLastFile,
    ],
  );

  const closeEditor = useCallback(() => {
    setEditorState((prev) => ({ ...prev, isOpen: false }));
  }, []);

  const openMovePromptDialog = useCallback(
    (fileId: string) => {
      const file = fileMap.get(fileId);
      if (!file) {
        showNotification("Prompt not found", "error");
        return;
      }

      setMovePromptState({
        isOpen: true,
        promptId: file.id,
        promptName: file.name,
        currentFolderId: file.folderId,
        selectedFolderId: "",
      });
    },
    [fileMap, showNotification],
  );

  const confirmMovePrompt = useCallback(async () => {
    if (!movePromptState.promptId || !movePromptState.selectedFolderId) return;

    try {
      const updated = await movePrompt(
        movePromptState.promptId,
        movePromptState.selectedFolderId,
      );

      showNotification("Template moved");
      setMovePromptState({
        isOpen: false,
        promptId: null,
        promptName: "",
        currentFolderId: null,
        selectedFolderId: "",
      });

      await loadWorkspace({ preserveFileId: updated.id });
    } catch (err) {
      showNotification(
        `Failed to move template: ${(err as Error).message}`,
        "error",
      );
    }
  }, [loadWorkspace, movePromptState, showNotification]);

  const getDescendantFolderIds = useCallback(
    (folderId: string, folders: { id: string; parentId: string | null }[]) => {
      const result = new Set<string>();
      const childrenByParent = new Map<string | null, string[]>();

      for (const folder of folders) {
        const list = childrenByParent.get(folder.parentId) ?? [];
        list.push(folder.id);
        childrenByParent.set(folder.parentId, list);
      }

      const stack = [...(childrenByParent.get(folderId) ?? [])];
      while (stack.length > 0) {
        const current = stack.pop()!;
        if (result.has(current)) continue;
        result.add(current);
        stack.push(...(childrenByParent.get(current) ?? []));
      }

      return result;
    },
    [],
  );

  const displayFolderParentPath = useCallback(
    (folderId: string | null, root: FolderNode | null) => {
      if (!root || !folderId) return "/Workspace";

      const all = flattenFolders(root);
      const found = all.find((folder) => folder.id === folderId);
      return found?.path ?? "/Workspace";
    },
    [],
  );

  const openMoveFolderDialog = useCallback(
    async (folderId: string) => {
      const folders = await getAllFolders();
      const target = folders.find((folder) => folder.id === folderId);

      if (!target) {
        showNotification("Folder not found", "error");
        return;
      }

      if (target.parentId === null) {
        showNotification("Root folder cannot be moved", "error");
        return;
      }

      setMoveFolderState({
        isOpen: true,
        folderId: target.id,
        folderName: target.name,
        currentParentId: target.parentId,
        currentParentPath: displayFolderParentPath(target.parentId, folderTree),
        selectedFolderId: "",
      });
    },
    [displayFolderParentPath, folderTree, showNotification],
  );

  const confirmMoveFolder = useCallback(async () => {
    if (!moveFolderState.folderId || !moveFolderState.selectedFolderId) return;

    try {
      const folders = await getAllFolders();
      const descendants = getDescendantFolderIds(
        moveFolderState.folderId,
        folders,
      );

      if (moveFolderState.selectedFolderId === moveFolderState.folderId) {
        showNotification("Cannot move a folder into itself", "error");
        return;
      }

      if (descendants.has(moveFolderState.selectedFolderId)) {
        showNotification("Cannot move a folder into its child", "error");
        return;
      }

      await moveFolder(
        moveFolderState.folderId,
        moveFolderState.selectedFolderId,
      );

      showNotification("Folder moved");
      setMoveFolderState({
        isOpen: false,
        folderId: null,
        folderName: "",
        currentParentId: null,
        currentParentPath: "/Workspace",
        selectedFolderId: "",
      });

      await loadWorkspace({ preserveFileId: currentFile?.id ?? null });
    } catch (err) {
      showNotification(
        `Failed to move folder: ${(err as Error).message}`,
        "error",
      );
    }
  }, [
    currentFile?.id,
    getDescendantFolderIds,
    loadWorkspace,
    moveFolderState,
    showNotification,
  ]);

  useEffect(() => {
    loadWorkspace({ restoreLastFile: true });
  }, [loadWorkspace]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (editorState.isOpen) return;

      const ctrl = e.ctrlKey || e.metaKey;

      if (ctrl && e.code === "KeyK") {
        e.preventDefault();
        setIsPaletteOpen((prev) => !prev);
        return;
      }

      if (ctrl && e.code === "KeyO") {
        e.preventDefault();
        selectFolder();
        return;
      }

      if (ctrl && e.code === "KeyN") {
        e.preventDefault();
        createNewFile();
        return;
      }

      if (ctrl && e.code === "KeyE" && currentFile) {
        e.preventDefault();
        openEditor(currentFile.id);
        return;
      }

      if (e.key === "Escape") {
        if (isPaletteOpen) {
          setIsPaletteOpen(false);
          return;
        }
        if (isDocsOpen) {
          setIsDocsOpen(false);
          return;
        }
        if (isTemplateOpen) {
          setIsTemplateOpen(false);
          return;
        }
      }

      if (e.altKey && e.code === "KeyR") {
        e.preventDefault();
        refreshFolder();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [
    isPaletteOpen,
    isDocsOpen,
    isTemplateOpen,
    currentFile,
    editorState.isOpen,
    selectFolder,
    refreshFolder,
    createNewFile,
    openEditor,
  ]);

  return (
    <div className="flex h-screen bg-background">
      <Sidebar
        folderTree={folderTree}
        currentFile={currentFile}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSelectFolder={selectFolder}
        onRefresh={refreshFolder}
        onFileSelect={loadFile as never}
        onEditFile={openEditor as never}
        onOpenTemplate={(fileId) => {
          loadFile(fileId as never);
          setIsTemplateOpen(true);
        }}
        onMoveFile={openMovePromptDialog as never}
        onCreateFile={createNewFile}
        onCreateFolder={createNewFolder}
        onRenameFolder={renameExistingFolder}
        onMoveFolder={openMoveFolderDialog}
        onDeleteFolder={deleteExistingFolder}
        onDeleteFile={deleteFile as never}
        isLoading={isLoading}
        isOpen={isSidebarOpen}
        onToggle={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      <MainContent
        currentFile={currentFile}
        currentParams={currentParams}
        isLoading={isLoading}
        onOpenDocs={() => setIsDocsOpen(true)}
        onOpenTemplate={() => setIsTemplateOpen(true)}
        onEditFile={() => currentFile && openEditor(currentFile.id)}
        onDeleteFile={() => currentFile && deleteFile(currentFile.id)}
        showNotification={showNotification}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        isSidebarOpen={isSidebarOpen}
      />

      <CommandPalette
        isOpen={isPaletteOpen}
        onClose={() => setIsPaletteOpen(false)}
        fileMap={fileMap}
        onFileSelect={(id) => {
          loadFile(id as never);
          setIsPaletteOpen(false);
        }}
      />

      <DocsModal isOpen={isDocsOpen} onClose={() => setIsDocsOpen(false)} />

      <TemplateModal
        isOpen={isTemplateOpen}
        onClose={() => setIsTemplateOpen(false)}
        content={currentFile?.content ?? currentFile?.bodyContent ?? ""}
      />

      {editorState.isOpen && (
        <CodeEditor
          content={editorState.content}
          fileName={editorState.fileName}
          isNew={editorState.isNew}
          onSave={saveFile}
          onClose={closeEditor}
          onDelete={
            editorState.isNew
              ? undefined
              : () => editorState.fileId && deleteFile(editorState.fileId)
          }
          showNotification={showNotification}
        />
      )}
      <MovePromptDialog
        isOpen={movePromptState.isOpen}
        promptName={movePromptState.promptName}
        currentFolderId={movePromptState.currentFolderId}
        folders={folderTree ? flattenFolders(folderTree) : []}
        selectedFolderId={movePromptState.selectedFolderId}
        onSelectedFolderIdChange={(value) =>
          setMovePromptState((prev) => ({ ...prev, selectedFolderId: value }))
        }
        onClose={() =>
          setMovePromptState({
            isOpen: false,
            promptId: null,
            promptName: "",
            currentFolderId: null,
            selectedFolderId: "",
          })
        }
        onConfirm={confirmMovePrompt}
      />
      <MoveFolderDialog
        isOpen={moveFolderState.isOpen}
        folderName={moveFolderState.folderName}
        currentParentPath={moveFolderState.currentParentPath}
        folders={
          folderTree
            ? flattenFolders(folderTree).filter((folder) => {
                if (!moveFolderState.folderId) return folder.id !== "root";

                const allFolders = flattenFolders(folderTree);
                const target = allFolders.find(
                  (folder) => folder.id === moveFolderState.folderId,
                );

                if (!target) return folder.id !== "root";

                const targetPathPrefix = `${target.path}/`;
                return (
                  folder.id !== moveFolderState.folderId &&
                  !folder.path.startsWith(targetPathPrefix)
                );
              })
            : []
        }
        selectedFolderId={moveFolderState.selectedFolderId}
        onSelectedFolderIdChange={(value) =>
          setMoveFolderState((prev) => ({ ...prev, selectedFolderId: value }))
        }
        onClose={() =>
          setMoveFolderState({
            isOpen: false,
            folderId: null,
            folderName: "",
            currentParentId: null,
            currentParentPath: "/Workspace",
            selectedFolderId: "",
          })
        }
        onConfirm={confirmMoveFolder}
      />
      <Toaster position="bottom-right" />
    </div>
  );
}
